package oyy3;

import java.util.List;  
  
public interface ToDoService {  
   
    public List<String> getTodos1(String user);

	public List<String> getTodos(String user);  
 }  